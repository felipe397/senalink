# Carpeta reportes/
Esta carpeta almacena archivos generados dinámicamente por el backend.

Tipos de archivos que se guardan aquí:
- Reportes PDF generados por PDFGenerator.php
- Archivos XML generados por XMLGenerator.php

IMPORTANTE:
- Asegúrate de que esta carpeta tenga permisos de escritura.
- Si estás en un servidor Apache, puedes usar un .htaccess para permitir acceso a archivos PDF/XML.
